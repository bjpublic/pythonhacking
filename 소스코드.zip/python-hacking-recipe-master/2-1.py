from pythonping import ping

ping("8.8.8.8", verbose=True, count=1)
ping("100.100.100.255", verbose=True, count=1)
